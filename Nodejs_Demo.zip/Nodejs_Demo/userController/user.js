// UserController.js
var express = require('express');
var router = express.Router();
var dateFormat  =   require('dateformat'); //for format date
var bodyParser = require('body-parser');
var Database= require('../db')
var  cryptr   =  require('cryptr');

 
 router.use(bodyParser.json({limit: '1500mb'}));
        router.use(bodyParser.urlencoded({limit: '1500mb',extended: true}));

/* Add User in Database*/
function addUserData(req, res) {
      
    req.check("first_name",     "first_name is required").notEmpty();
    req.check("last_name",     "last_name is required").notEmpty();
    req.check("email",  "email is required").notEmpty();
    req.check("email", "The email field must contain a valid email address").isEmail();
    req.check("password",   "password is required").notEmpty();
    req.check("mobile_no",    "mobile_no required").notEmpty();
    req.check("mobile_no", "The mobile_no field must contain Number only").isNumeric();
   
     req.getValidationResult().then(function(result) {
       if (!result.isEmpty()) {
            var errors = result.array();  
            res.send({"message":errors[0].msg,"params":errors[0].param,"status":false,"Session_status":true});
        }
        else{ 
              var created_at1       = new Date;
              var created_at        = dateFormat(created_at1.request_date, "yyyy-mm-dd hh:MM:ss"); //date format
               // var password =  cryptr.encrypt(req.body.password);
              var password=req.body.password
              var userData ="INSERT INTO `user`(first_name,last_name,email,password,mobile_no,created_at,updated_at) VALUES ('"+req.body.first_name+"','"+req.body.last_name+"','"+req.body.email+"','"+password+"','"+req.body.mobile_no+"','"+created_at+"','"+created_at+"')"; 

               Database.exeQuery(userData,function(err,user) {
               if (err) return res.status(500).send({"Data":"","message":"There was a problem adding the information to the database.","status":false,"err_code":0});
                 res.status(200).send({"message":"User Added Successfully"});
            })
        }
    })

}

/**********************/
/* For Finding All User Data*/
function getUserData(req,res)
{
    Database.exeQuery("SELECT * FROM user ",function(err,user) {
       if (err) return  res.status(500).send({"Data":"","message":"There was a problem finding the users.","status":false,"err_code":0});
       if(!user)
        return res.status(404).send({"Data":user,"message":"No user found.","status":true,"err_code":1});
        res.status(200).send({"Data":user,"message":"Get All Data Successfully","status":true,"err_code":1});
    })

}

/*************************/
 
 /* For Get One User Data*/
function getOneUserData(req,res)
{
  var getOneUser ="SELECT * FROM user WHERE id="+req.body.id; 
    Database.exeQuery(getOneUser,function(err,user) {
        if (err) return res.status(500).send({"Data":"","message":"There was a problem finding the users.","status":false,"err_code":0});
          if(!user)
              {
                 return res.status(200).send(user);
              } 
            else{
                 return res.status(404).send({"Data":user,"message":"No user found.","status":true,"err_code":1});
              }
      })
}

/*************************/

  /* Add User in Database*/
function updateUserData(req, res) {
    req.check("id",     " user id is required").notEmpty();
    req.check("first_name",     "first_name is required").notEmpty();
    req.check("last_name",     "last_name is required").notEmpty();
    req.check("email",  "email is required").notEmpty();
    req.check("email", "The email field must contain a valid email address").isEmail();
    req.check("password",   "password is required").notEmpty();
    req.check("mobile_no",    "mobile_no required").notEmpty();
    req.check("mobile_no", "The mobile_no field must contain Number only").isNumeric();
   
     req.getValidationResult().then(function(result) {
       if (!result.isEmpty()) {
            var errors = result.array();  
            res.send({"message":errors[0].msg,"params":errors[0].param,"status":false,"Session_status":true});
        }
        else{ 
              var created_at1       = new Date;
              var created_at        = dateFormat(created_at1.request_date, "yyyy-mm-dd hh:MM:ss"); //date format
               // var password =  cryptr.encrypt(req.body.password);
              var password=req.body.password
                var updateUserInfo= "UPDATE `user` SET `first_name`='"+req.body.first_name+"',`last_name`='"+req.body.last_name+"',`email`='"+req.body.email+"',`password`='"+password+"',`mobile_no`='"+req.body.mobile_no+"',`updated_at`='"+created_at+"' WHERE id="+req.body.id+" ";   
               Database.exeQuery(updateUserInfo,function(err,user) {
               if (err) return res.status(500).send({"Data":"","message":"There was a problem updating the User.","status":false,"err_code":0});
                 res.status(200).send({"message":"User update Successfully","status":true,"err_code":1,"Data":user[0]});
            })
        }
    })

}


/*************************/

  /* For Login User Database*/
function loginUser(req, res) {
   req.check("email",  "email is required").notEmpty();
    req.check("email", "The email field must contain a valid email address").isEmail();
    req.check("password",   "password is required").notEmpty();
  
     req.getValidationResult().then(function(result) {
       if (!result.isEmpty()) {
            var errors = result.array();  
            res.send({"message":errors[0].msg,"params":errors[0].param,"status":false,"Session_status":true});
        }
        else{ 
              var created_at1       = new Date;
              var created_at        = dateFormat(created_at1.request_date, "yyyy-mm-dd hh:MM:ss"); //date format
               // var password =  cryptr.encrypt(req.body.password);
              var password=req.body.password
               var loginUser ="SELECT * FROM user WHERE email='"+req.body.email+"' AND password='"+req.body.password+"'"; 
               Database.exeQuery(loginUser,function(err,user) {
               if (err) return res.status(500).send({"Data":"","message":"There was a problem login the User.","status":false,"err_code":0});
                   if(!user)
                    {
                        return res.status(200).send({"message":"User login Successfully","status":true,"err_code":1,"Data":user[0]});
                    } 
                     else{
                         return res.status(404).send({"Data":user,"message":"Please Enter Right Email And Password","status":true,"err_code":1});
                      }

            })
        }
    })

}


router.post('/login-user', loginUser);
router.post('/add-user', addUserData);
router.get('/get-user', getUserData);
router.post('/get-one-user', getOneUserData);
router.post('/update-user', updateUserData);


module.exports = router





// RETURNS ALL THE USERS IN THE DATABASE
// router.get('/', function (req, res) {
//     Database.find({}, function (err, users) {
//         if (err) return res.status(500).send({"message":"There was a problem finding the users.","status":false,"err_code":0});
//         if(!user)
//         res.status(200).send({"message":"There was a problem finding the users.","status":false,"err_code":0});
//     });
// });