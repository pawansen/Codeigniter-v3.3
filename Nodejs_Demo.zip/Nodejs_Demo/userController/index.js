


const express = require('express');
const categoryRoutes = require('./user');



const router = express.Router();


// router.use(authenticator);
router.use('/user-api', categoryRoutes);

module.exports = router;