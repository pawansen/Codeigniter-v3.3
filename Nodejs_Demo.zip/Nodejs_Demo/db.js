﻿      "use strict";
      /*
       * File name: dataBase.js
       *Purpose: Connect and perform database operetion.
       * Arthur : Sourabh Dhariwal
       *  Date :23-march-2017
      */

      var mysql = require('mysql');

      var Database = function() {
        var that = this;
        this.connection = mysql.createPool({
            host: 'localhost',
            user: 'root',
            password: 'root',
            database: 'newNodejsDemo',
            debug: false
           });
      } //Database

      Database.prototype.getConnection = function(query, callBack) {
        return this.connection;
      } //getConn

      Database.prototype.endConnection = function(query, callBack) {
        this.connection.end();
      } //getConn

      Database.prototype.exeQuery = function(query, callBack) {
        //this.mariasqlconnection.query('SHOW DATABASES', function (err, rows) {
        this.connection.query(query, function(error, results, fields) {
          callBack(error, results);
        });
      } //getConn

      module.exports = new Database();
